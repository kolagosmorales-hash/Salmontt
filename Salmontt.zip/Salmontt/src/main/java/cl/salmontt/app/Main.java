package cl.salmontt.app;


import cl.salmontt.model.*;


public class Main {
    public static void main(String[] args) {


// Direcciones
        Direccion d1 = new Direccion("Avenida Austral", "456", "Puerto Montt", "Los Lagos", "Chile");
        Direccion d2 = new Direccion("René Schneider", "1120", "Puerto Varas", "Los Lagos", "Chile");
        Direccion d3 = new Direccion("Cañuela", "215", "Calbuco", "Los Lagos", "Chile");


// Persona visitante
        Persona p1 = new Persona(
                "18.657.239-1",
                "Camila Alvarado Soto",
                "camila.alvarado@salmontt.cl",
                "+56 9 8123 4412",
                d2
        );


// Empleados
        Empleado e1 = new Empleado(
                "14.892.334-5",
                "Rodrigo Cárdenas Núñez",
                "rcardenas@salmontt.cl",
                "+56 9 7321 9087",
                d1,
                "E-1021",
                "Jefe de Turno",
                "Planta de Procesos",
                1350000
        );


        Empleado e2 = new Empleado(
                "17.452.889-7",
                "Daniela Bustos Alarcón",
                "dbustos@salmontt.cl",
                "+56 9 9455 3271",
                d3,
                "E-2044",
                "Analista de Calidad",
                "Aseguramiento de Calidad (QA)",
                1120000
        );


        Empleado e3 = new Empleado(
                "16.225.441-3",
                "José Obando Reyes",
                "jobando@salmontt.cl",
                "+56 9 7785 1123",
                d1,
                "E-3055",
                "Supervisor de Centro",
                "Operaciones Marinas",
                1580000
        );


// Impresión ordenada
        System.out.println(p1);
        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);
    }
}