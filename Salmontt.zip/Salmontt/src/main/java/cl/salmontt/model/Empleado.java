package cl.salmontt.model;

public class Empleado extends Persona {

    private String idEmpleado;
    private String cargo;
    private String area;
    private int sueldo;

    public Empleado(String rut, String nombre, String email, String telefono, Direccion direccion,
                    String idEmpleado, String cargo, String area, int sueldo) {

        super(rut, nombre, email, telefono, direccion);
        this.idEmpleado = idEmpleado;
        this.cargo = cargo;
        this.area = area;
        this.sueldo = sueldo;
    }

    public String getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "----- EMPLEADO -----\n" +
                "ID Empleado: " + idEmpleado + "\n" +
                "Cargo: " + cargo + "\n" +
                "Área: " + area + "\n" +
                "Sueldo: " + sueldo + "\n" +
                "Datos de Persona:\n" + super.toString();
    }
}
